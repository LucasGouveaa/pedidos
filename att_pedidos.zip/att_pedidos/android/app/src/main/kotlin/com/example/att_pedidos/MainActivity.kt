package com.example.att_pedidos

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
